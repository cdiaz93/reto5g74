/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import modelo.VO.*;
import java.util.ArrayList;
import controlador.ControladorRequerimiento;



/**
 *
 * @author Davinchi
 */
public class VistaRequerimientos {
  
    public static final ControladorRequerimiento controlador = new ControladorRequerimiento();

    public static void requerimiento1(){
        try {
            ArrayList<LideresVO> requerimiento1s = controlador.consultaRequerimiento1();

            System.out.println("Requerimiento 1, Consulta 1:");
            System.out.println("Nombre Documento_Identidad");
            
  
            
            for(LideresVO requerimiento1 : requerimiento1s){
                System.out.printf("%s %s %n", requerimiento1.getNombre(), requerimiento1.getDocumento_identidad());
            }
        } catch (Exception e) {
            System.err.println(e);

        }
    }


    public static void requerimiento2(){
        try {
            ArrayList<MaterialesProyectosVO> requerimiento2s = controlador.consultaRequerimiento2();

            System.out.println("Requerimiento 2, Consulta 4:");
            System.out.println("Nombre_Material Precio_Unidad Total");

            for(MaterialesProyectosVO requerimiento2 : requerimiento2s){
                // %s = es en formato texto
                // %d es en formato numero
                // %n se hace un salto de linea
                System.out.printf("%s %s %s %n", 
                requerimiento2.getNombre_material(), 
                requerimiento2.getPrecio_material(), 
                requerimiento2.getTotal());
            }
        } catch (Exception e) {
           System.err.println(e);
        }
    }

    public static void requerimiento3(){

        try {
            ArrayList<LideresCostoPromVO> requerimiento3s = controlador.consultaRequerimiento3();

            System.out.println("Requerimiento 1, Consulta 1:");
            System.out.println("Nombre Documento_Identidad");

            for(LideresCostoPromVO requerimiento3 : requerimiento3s){
                System.out.printf("%s %s %n", requerimiento3.getNombre(), requerimiento3.getPromedio());
            }
        } catch (Exception e) {
            System.err.println(e);
        }
    }  
}
