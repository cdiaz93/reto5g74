/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.VO;

/**
 *
 * @author Davinchi
 */
public class LideresCostoPromVO {
    
    
    private String nombre;
    private String promedio;


    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getPromedio() {
        return promedio;
    }
    public void setPromedio(String promedio) {
        this.promedio = promedio;
    }
}
