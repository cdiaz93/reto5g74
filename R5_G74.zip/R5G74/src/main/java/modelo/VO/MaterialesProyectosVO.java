/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.VO;

/**
 *
 * @author Davinchi
 */
public class MaterialesProyectosVO {
    
    
    private String nombre_material;
    private String precio_material;
    private String total;


    public String getNombre_material() {
        return nombre_material;
    }
    public void setNombre_material(String nombre_material) {
        this.nombre_material = nombre_material;
    }
    public String getPrecio_material() {
        return precio_material;
    }
    public void setPrecio_material(String precio_material) {
        this.precio_material = precio_material;
    }
    public String getTotal() {
        return total;
    }
    public void setTotal(String total) {
        this.total = total;
    }
}
