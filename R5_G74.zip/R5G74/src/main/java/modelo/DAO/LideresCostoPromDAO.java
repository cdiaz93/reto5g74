/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.DAO;

import java.sql.SQLException;
import java.util.ArrayList;

import modelo.VO.LideresCostoPromVO;
import util.JDBCutilities;

/**
 *
 * @author Davinchi
 */
public class LideresCostoPromDAO {
    
    public ArrayList<LideresCostoPromVO>requerimiento3() throws SQLException{

        var response = new ArrayList<LideresCostoPromVO>();
        String consulta = "SELECT  l.Nombre || ' '  || l.Primer_Apellido || ' '  || l.Segundo_Apellido as Nombre, "
        + "SUM(mc.Precio_Unidad*c.Cantidad)/ COUNT(DISTINCT p.ID_Proyecto) as Promedio "
        + "FROM Lider l "
        + "INNER JOIN Proyecto p ON l.ID_Lider  = p.ID_Lider "
        + "INNER JOIN Compra c ON p.ID_Proyecto = c.ID_Proyecto "
        + "INNER JOIN MaterialConstruccion mc ON c.ID_MaterialConstruccion  = mc.ID_MaterialConstruccion "
        + "WHERE p.Ciudad  = 'Pereira' "
        + "GROUP BY l.Nombre || ' '  || l.Primer_Apellido || ' '  || l.Segundo_Apellido "
        + "HAVING COUNT(DISTINCT p.ID_proyecto) >=2 "
        + "ORDER BY Promedio DESC "
        + "LIMIT 3;";

        try(
            var connection =JDBCutilities.getConnection();
            var statement = connection.prepareStatement(consulta);
            var rset= statement.executeQuery();
        ){
           while(rset.next()){
               var requerimiento_3VO= new LideresCostoPromVO();
               requerimiento_3VO.setNombre(rset.getString("Nombre"));
               requerimiento_3VO.setPromedio(rset.getString("Promedio"));

               response.add(requerimiento_3VO);
           }       
        }

        return response;

    }
}
