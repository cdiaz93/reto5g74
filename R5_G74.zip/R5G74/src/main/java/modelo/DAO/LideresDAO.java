/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.DAO;

import java.sql.SQLException;
import java.util.ArrayList;


import modelo.VO.LideresVO;
import util.JDBCutilities;

/**
 *
 * @author Davinchi
 */
public class LideresDAO {
    
        public ArrayList<LideresVO>requerimiento1() throws SQLException{

        var response = new ArrayList<LideresVO>();
        String consulta ="SELECT Nombre || ' ' || Primer_Apellido || ' ' || Segundo_Apellido  as Nombre , Documento_Identidad "
        + "FROM Lider WHERE Ciudad_Residencia  = 'Barranquilla' "
        + "ORDER BY Nombre;";

        try(
            var connection =JDBCutilities.getConnection();
            var statement = connection.prepareStatement(consulta);
            var rset= statement.executeQuery();
        ){
           while(rset.next()){

               var requerimiento_1VO= new LideresVO();
               requerimiento_1VO.setNombre(rset.getString("Nombre"));
               requerimiento_1VO.setDocumento_identidad(rset.getString("Documento_identidad"));

               response.add(requerimiento_1VO);
           }       
        }

        return response;

    }
}
