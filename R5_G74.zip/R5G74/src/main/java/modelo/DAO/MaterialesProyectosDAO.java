/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.DAO;

import java.sql.SQLException;
import java.util.ArrayList;

import modelo.VO.MaterialesProyectosVO;
import util.JDBCutilities;

/**
 *
 * @author Davinchi
 */
public class MaterialesProyectosDAO {
        public ArrayList<MaterialesProyectosVO>requerimiento2() throws SQLException{

        var response = new ArrayList<MaterialesProyectosVO>();
        String consulta = "SELECT  mc.Nombre_Material, mc.Precio_Unidad , SUM(c.Cantidad)  as Total "
        + "FROM MaterialConstruccion mc INNER JOIN Compra c " 
        + "ON mc.ID_MaterialConstruccion = c.ID_MaterialConstruccion "
        + "WHERE c.ID_Proyecto  IN (183, 331, 352, 365, 76) "
        + "GROUP BY  mc.Nombre_Material "
        + "ORDER  BY mc.Nombre_Material ASC;";

        try(
            var connection =JDBCutilities.getConnection();
            var statement = connection.prepareStatement(consulta);
            var rset= statement.executeQuery();
        ){
           while(rset.next()){
               var requerimiento_2VO= new MaterialesProyectosVO();
               requerimiento_2VO.setNombre_material(rset.getString("Nombre_Material"));
               requerimiento_2VO.setPrecio_material(rset.getString("Precio_Unidad"));
               requerimiento_2VO.setTotal(rset.getString("Total"));

               response.add(requerimiento_2VO);
           }       
        }

        return response;

    }
}
