/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.sql.SQLException;
import java.util.ArrayList;

import modelo.VO.*;
import modelo.DAO.*;

/**
 *
 * @author Davinchi
 */
public class ControladorRequerimiento {
    
    private LideresDAO requerimiento1;
    private MaterialesProyectosDAO requerimiento2;
    private LideresCostoPromDAO requerimiento3;

    public ControladorRequerimiento(){
        this.requerimiento1 = new LideresDAO();
        this.requerimiento2 = new MaterialesProyectosDAO();
        this.requerimiento3 = new LideresCostoPromDAO();
    }

    public ArrayList<LideresVO> consultaRequerimiento1() throws SQLException{
        return requerimiento1.requerimiento1();
    }
    public ArrayList<MaterialesProyectosVO> consultaRequerimiento2() throws SQLException{
        return requerimiento2.requerimiento2();
    }

    public ArrayList<LideresCostoPromVO> consultaRequerimiento3() throws SQLException{
        return requerimiento3.requerimiento3();
    }
}
